var list = document.getElementById('valueList');
var text = '<span> younhave selected : </span>';
var listArray = [];

var checkboxes = document.querySelectorAll('.checkbox');

for(var checkbox of checkboxes){
    checkbox.addEventListener('click',function(){
        if(this.checked == true){
            listArray.push(this.value);
            list.innerHTML = text + listArray.join(' , ')
        }else{
            listArray = listArray.filter(e => e !== this.value);
            list.innerHTML = text + listArray.join(' , ')
        }
    })
}