package com.hcc.ttrts.Models;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Trainer {

	@Id
	@GeneratedValue( strategy = GenerationType.AUTO)
	long id;
//	String name, email, password, gender;
	String name, email, password, gender,selectcourseName;
	long per;
	
	@OneToOne
	Course course;

	public Trainer() {

	}

	public Trainer(long id, String name, String email, String password, String gender,String selectcourseName,long per) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.gender = gender;
		this.selectcourseName = selectcourseName;
		this.per = per;
	}

	
	
	
	public String getSelectcourseName() {
		return selectcourseName;
	}

	public void setSelectcourseName(String selectcourseName) {
		this.selectcourseName = selectcourseName;
	}

	
	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public long getPer() {
		return id;
	}

	public void setPer(long l) {
		this.per = l;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


}
