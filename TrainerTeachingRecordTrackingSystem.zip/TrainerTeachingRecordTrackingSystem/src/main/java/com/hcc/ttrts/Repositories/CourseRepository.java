package com.hcc.ttrts.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;


import com.hcc.ttrts.Models.Course;

public interface CourseRepository extends JpaRepository<Course, Integer>{

}
