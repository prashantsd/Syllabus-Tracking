package com.hcc.ttrts.Repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Service;

import com.hcc.ttrts.Models.Trainer;

@Service
public interface TrainerRepository extends JpaRepository<Trainer, Long> {

	Trainer findById(long id);

	
	
}

