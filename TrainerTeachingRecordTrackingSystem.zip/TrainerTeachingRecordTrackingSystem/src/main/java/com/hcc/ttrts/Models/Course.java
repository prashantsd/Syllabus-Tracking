package com.hcc.ttrts.Models;

import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Course {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	
	String courseName;
	
//	String p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20;
	
	String p1="DataTypes",p2="Collection",p3="ArrayList",p4="DataTypes",p5="Collection",p6="ArrayList",
			p7="DataTypes",p8="Collection",p9="ArrayList",p10="DataTypes",p11="Collection",
			p12="ArrayList",p13="DataTypes",p14="Collection",p15="ArrayList",p16="DataTypes",
			p17="Collection",p18="ArrayList",p19="DataTypes",p20="Collection";
			
	
	boolean c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getCourseName() {
		return courseName;
	}


	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}


	public String getP1() {
		return p1;
	}


	public void setP1(String p1) {
		this.p1 = p1;
	}


	public String getP2() {
		return p2;
	}


	public void setP2(String p2) {
		this.p2 = p2;
	}


	public String getP3() {
		return p3;
	}


	public void setP3(String p3) {
		this.p3 = p3;
	}


	public String getP4() {
		return p4;
	}


	public void setP4(String p4) {
		this.p4 = p4;
	}


	public String getP5() {
		return p5;
	}


	public void setP5(String p5) {
		this.p5 = p5;
	}


	public String getP6() {
		return p6;
	}


	public void setP6(String p6) {
		this.p6 = p6;
	}


	public String getP7() {
		return p7;
	}


	public void setP7(String p7) {
		this.p7 = p7;
	}


	public String getP8() {
		return p8;
	}


	public void setP8(String p8) {
		this.p8 = p8;
	}


	public String getP9() {
		return p9;
	}


	public void setP9(String p9) {
		this.p9 = p9;
	}


	public String getP10() {
		return p10;
	}


	public void setP10(String p10) {
		this.p10 = p10;
	}


	public String getP11() {
		return p11;
	}


	public void setP11(String p11) {
		this.p11 = p11;
	}


	public String getP12() {
		return p12;
	}


	public void setP12(String p12) {
		this.p12 = p12;
	}


	public String getP13() {
		return p13;
	}


	public void setP13(String p13) {
		this.p13 = p13;
	}


	public String getP14() {
		return p14;
	}


	public void setP14(String p14) {
		this.p14 = p14;
	}


	public String getP15() {
		return p15;
	}


	public void setP15(String p15) {
		this.p15 = p15;
	}


	public String getP16() {
		return p16;
	}


	public void setP16(String p16) {
		this.p16 = p16;
	}


	public String getP17() {
		return p17;
	}


	public void setP17(String p17) {
		this.p17 = p17;
	}


	public String getP18() {
		return p18;
	}


	public void setP18(String p18) {
		this.p18 = p18;
	}


	public String getP19() {
		return p19;
	}


	public void setP19(String p19) {
		this.p19 = p19;
	}


	public String getP20() {
		return p20;
	}


	public void setP20(String p20) {
		this.p20 = p20;
	}


	public boolean isC1() {
		return c1;
	}


	public void setC1(boolean c1) {
		this.c1 = c1;
	}


	public boolean isC2() {
		return c2;
	}


	public void setC2(boolean c2) {
		this.c2 = c2;
	}


	public boolean isC3() {
		return c3;
	}


	public void setC3(boolean c3) {
		this.c3 = c3;
	}


	public boolean isC4() {
		return c4;
	}


	public void setC4(boolean c4) {
		this.c4 = c4;
	}


	public boolean isC5() {
		return c5;
	}


	public void setC5(boolean c5) {
		this.c5 = c5;
	}


	public boolean isC6() {
		return c6;
	}


	public void setC6(boolean c6) {
		this.c6 = c6;
	}


	public boolean isC7() {
		return c7;
	}


	public void setC7(boolean c7) {
		this.c7 = c7;
	}


	public boolean isC8() {
		return c8;
	}


	public void setC8(boolean c8) {
		this.c8 = c8;
	}


	public boolean isC9() {
		return c9;
	}


	public void setC9(boolean c9) {
		this.c9 = c9;
	}


	public boolean isC10() {
		return c10;
	}


	public void setC10(boolean c10) {
		this.c10 = c10;
	}


	public boolean isC11() {
		return c11;
	}


	public void setC11(boolean c11) {
		this.c11 = c11;
	}


	public boolean isC12() {
		return c12;
	}


	public void setC12(boolean c12) {
		this.c12 = c12;
	}


	public boolean isC13() {
		return c13;
	}


	public void setC13(boolean c13) {
		this.c13 = c13;
	}


	public boolean isC14() {
		return c14;
	}


	public void setC14(boolean c14) {
		this.c14 = c14;
	}


	public boolean isC15() {
		return c15;
	}


	public void setC15(boolean c15) {
		this.c15 = c15;
	}


	public boolean isC16() {
		return c16;
	}


	public void setC16(boolean c16) {
		this.c16 = c16;
	}


	public boolean isC17() {
		return c17;
	}


	public void setC17(boolean c17) {
		this.c17 = c17;
	}


	public boolean isC18() {
		return c18;
	}


	public void setC18(boolean c18) {
		this.c18 = c18;
	}


	public boolean isC19() {
		return c19;
	}


	public void setC19(boolean c19) {
		this.c19 = c19;
	}


	public boolean isC20() {
		return c20;
	}


	public void setC20(boolean c20) {
		this.c20 = c20;
	}
	
	
	
	
//	public int getId() {
//		return id;
//	}
//	public void setId(int id) {
//		this.id = id;
//	}
//	public String getCourseName() {
//		return courseName;
//	}
//	public void setCourseName(String courseName) {
//		this.courseName = courseName;
//	}
//	public String getP1() {
//		return p1;
//	}
//	public void setP1(String p1) {
//		this.p1 = p1;
//	}
//	public String getP2() {
//		return p2;
//	}
//	public void setP2(String p2) {
//		this.p2 = p2;
//	}
//	public String getP3() {
//		return p3;
//	}
//	public void setP3(String p3) {
//		this.p3 = p3;
//	}
//	public String getP4() {
//		return p4;
//	}
//	public void setP4(String p4) {
//		this.p4 = p4;
//	}
//	public String getP5() {
//		return p5;
//	}
//	public void setP5(String p5) {
//		this.p5 = p5;
//	}
//	public String getP6() {
//		return p6;
//	}
//	public void setP6(String p6) {
//		this.p6 = p6;
//	}
//	public String getP7() {
//		return p7;
//	}
//	public void setP7(String p7) {
//		this.p7 = p7;
//	}
//	public String getP8() {
//		return p8;
//	}
//	public void setP8(String p8) {
//		this.p8 = p8;
//	}
//	public String getP9() {
//		return p9;
//	}
//	public void setP9(String p9) {
//		this.p9 = p9;
//	}
//	public String getP10() {
//		return p10;
//	}
//	public void setP10(String p10) {
//		this.p10 = p10;
//	}
//	public String getP11() {
//		return p11;
//	}
//	public void setP11(String p11) {
//		this.p11 = p11;
//	}
//	public String getP12() {
//		return p12;
//	}
//	public void setP12(String p12) {
//		this.p12 = p12;
//	}
//	public String getP13() {
//		return p13;
//	}
//	public void setP13(String p13) {
//		this.p13 = p13;
//	}
//	public String getP14() {
//		return p14;
//	}
//	public void setP14(String p14) {
//		this.p14 = p14;
//	}
//	public String getP15() {
//		return p15;
//	}
//	public void setP15(String p15) {
//		this.p15 = p15;
//	}
//	public String getP16() {
//		return p16;
//	}
//	public void setP16(String p16) {
//		this.p16 = p16;
//	}
//	public String getP17() {
//		return p17;
//	}
//	public void setP17(String p17) {
//		this.p17 = p17;
//	}
//	public String getP18() {
//		return p18;
//	}
//	public void setP18(String p18) {
//		this.p18 = p18;
//	}
//	public String getP19() {
//		return p19;
//	}
//	public void setP19(String p19) {
//		this.p19 = p19;
//	}
//	public String getP20() {
//		return p20;
//	}
//	public void setP20(String p20) {
//		this.p20 = p20;
//	}
//	public boolean isC1() {
//		return c1;
//	}
//	public void setC1(boolean c1) {
//		this.c1 = c1;
//	}
//	public boolean isC2() {
//		return c2;
//	}
//	public void setC2(boolean c2) {
//		this.c2 = c2;
//	}
//	public boolean isC3() {
//		return c3;
//	}
//	public void setC3(boolean c3) {
//		this.c3 = c3;
//	}
//	public boolean isC4() {
//		return c4;
//	}
//	public void setC4(boolean c4) {
//		this.c4 = c4;
//	}
//	public boolean isC5() {
//		return c5;
//	}
//	public void setC5(boolean c5) {
//		this.c5 = c5;
//	}
//	public boolean isC6() {
//		return c6;
//	}
//	public void setC6(boolean c6) {
//		this.c6 = c6;
//	}
//	public boolean isC7() {
//		return c7;
//	}
//	public void setC7(boolean c7) {
//		this.c7 = c7;
//	}
//	public boolean isC8() {
//		return c8;
//	}
//	public void setC8(boolean c8) {
//		this.c8 = c8;
//	}
//	public boolean isC9() {
//		return c9;
//	}
//	public void setC9(boolean c9) {
//		this.c9 = c9;
//	}
//	public boolean isC10() {
//		return c10;
//	}
//	public void setC10(boolean c10) {
//		this.c10 = c10;
//	}
//	public boolean isC11() {
//		return c11;
//	}
//	public void setC11(boolean c11) {
//		this.c11 = c11;
//	}
//	public boolean isC12() {
//		return c12;
//	}
//	public void setC12(boolean c12) {
//		this.c12 = c12;
//	}
//	public boolean isC13() {
//		return c13;
//	}
//	public void setC13(boolean c13) {
//		this.c13 = c13;
//	}
//	public boolean isC14() {
//		return c14;
//	}
//	public void setC14(boolean c14) {
//		this.c14 = c14;
//	}
//	public boolean isC15() {
//		return c15;
//	}
//	public void setC15(boolean c15) {
//		this.c15 = c15;
//	}
//	public boolean isC16() {
//		return c16;
//	}
//	public void setC16(boolean c16) {
//		this.c16 = c16;
//	}
//	public boolean isC17() {
//		return c17;
//	}
//	public void setC17(boolean c17) {
//		this.c17 = c17;
//	}
//	public boolean isC18() {
//		return c18;
//	}
//	public void setC18(boolean c18) {
//		this.c18 = c18;
//	}
//	public boolean isC19() {
//		return c19;
//	}
//	public void setC19(boolean c19) {
//		this.c19 = c19;
//	}
//	public boolean isC20() {
//		return c20;
//	}
//	public void setC20(boolean c20) {
//		this.c20 = c20;
//	}
//	
	
	
	
	
}
