package com.hcc.ttrts.Controllers;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.hcc.ttrts.Models.Course;
import com.hcc.ttrts.Models.Trainer;
import com.hcc.ttrts.Repositories.CourseRepository;
import com.hcc.ttrts.Repositories.TrainerRepository;


@RestController
@RequestMapping
@CrossOrigin(origins = "http://localhost:4200")
public class TrainerController {
	
	
	@Autowired
	TrainerRepository trainerRepository;
	
	
	@Autowired
	CourseRepository courseRepository;
	
	
	@GetMapping("/trainers")
	public List<Trainer> display() {
		return trainerRepository.findAll();
	}
	
	
	@PostMapping("/addTrainer")
	public Trainer save(@RequestBody Trainer t){
		return trainerRepository.save(t);
	}
	
	
	@PutMapping("/updateTrainer")
	public Trainer update(@RequestBody Trainer t) {
		return trainerRepository.save(t);
	}
	
	
	@DeleteMapping("/deleteTrainer/{id}")
	public String delete(@PathVariable("id") long id) {
		trainerRepository.deleteById(id);
		return "Deleted";	
	}
	
	
	// Authentication api
		
	
	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody Trainer userdata){
		System.out.print(userdata);
		Trainer user = trainerRepository.findById(userdata.getId());
				
		
		if(user.getPassword().equals(userdata.getPassword()))
			return ResponseEntity.ok(user);
	
		return  (ResponseEntity<?>) ResponseEntity.internalServerError();
	}
	
	
	// get trainer by id rest API

		@GetMapping("/trainerdetail/{id}")
		public Trainer getTrainerById(@PathVariable Long id) {
			Trainer st = trainerRepository.findById(id).get();
			return trainerRepository.findById(id).get();
		}
		

		@CrossOrigin
		@PutMapping("/trainerupdateper/{id}")
		public Trainer updateStudent(@PathVariable int id, @RequestBody Trainer trainer){
			Trainer st = trainerRepository.findById(id);
			st.setPer(trainer.getPer());
						
			return trainerRepository.save(st);
		}
}
