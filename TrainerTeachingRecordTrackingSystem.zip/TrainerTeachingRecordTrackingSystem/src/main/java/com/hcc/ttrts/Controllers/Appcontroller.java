package com.hcc.ttrts.Controllers;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Appcontroller {
	
	@RequestMapping("/login")
	public String home() {
		System.out.println("This is Login load.......");
		return "login";
	}

}
